import { Mail, Phone } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';

export default function Blog() {
  const { data: posts, isLoading } = trpc.blog.list.useQuery();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-md">
        <div className="bg-secondary text-secondary-foreground py-2 px-4 md:px-8 text-sm flex flex-col md:flex-row justify-between items-center gap-2">
          <div className="flex gap-4 items-center">
            <a href="tel:+923154216083" className="hover:text-accent transition-colors flex items-center gap-1">
              <Phone size={16} /> +92 315 4216083
            </a>
            <a href="mailto:ironartofficial3@gmail.com" className="hover:text-accent transition-colors flex items-center gap-1">
              <Mail size={16} /> ironartofficial3@gmail.com
            </a>
          </div>
          <span className="text-xs md:text-sm font-medium">5+ Years of Excellence in Metal Fabrication</span>
        </div>

        <nav className="flex items-center justify-between px-4 md:px-8 py-4">
          <a href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
              <span className="font-bold text-accent-foreground text-lg">IA</span>
            </div>
            <span className="font-bold text-foreground hidden sm:inline">Iron Art</span>
          </a>

          <ul className="hidden md:flex gap-8 items-center">
            {['Home', 'About', 'Services', 'Products', 'Contact', 'Query', 'Blog'].map((item) => (
              <li key={item}>
                <a href={`/${item.toLowerCase()}`} className="text-foreground hover:text-accent transition-colors font-medium">
                  {item}
                </a>
              </li>
            ))}
          </ul>

          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
            Get a Custom Quote
          </Button>
        </nav>
      </header>

      {/* Blog Section */}
      <section className="py-16 md:py-24">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Blog</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Latest insights, tips, and updates about metal fabrication and custom metal art.
            </p>
          </div>

          {isLoading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Loading blog posts...</p>
            </div>
          ) : posts && posts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {posts.map((post) => (
                <article
                  key={post.id}
                  className="bg-card rounded-lg overflow-hidden border border-border hover:border-accent transition-all hover:shadow-lg"
                >
                  {post.imageUrl && (
                    <div
                      className="h-48 bg-cover bg-center"
                      style={{ backgroundImage: `url('${post.imageUrl}')` }}
                    />
                  )}
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold text-accent uppercase">
                        {post.category}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(post.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold mb-2 line-clamp-2">{post.title}</h3>
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                      {post.excerpt || post.content.substring(0, 150)}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">By {post.author}</span>
                      <a
                        href={`/blog/${post.slug}`}
                        className="text-accent font-semibold hover:text-accent/80 transition-colors"
                      >
                        Read More →
                      </a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No blog posts available yet.</p>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary text-secondary-foreground py-12 md:py-16">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center">
            <p className="text-sm text-secondary-foreground/80">
              © 2025 Iron Art. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

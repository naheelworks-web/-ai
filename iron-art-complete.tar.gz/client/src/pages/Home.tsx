import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Mail, Phone, MapPin, Facebook, Instagram, Twitter, Linkedin } from 'lucide-react';

export default function Home() {

  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlay, setIsAutoPlay] = useState(true);

  const slides = [
    {
      title: 'Precision Metal Cutting Services',
      subtitle: 'Industrial-grade CNC plasma and laser cutting solutions',
      image: '/images/Wd3LH54Gc5BC.jpg',
      cta: 'Get a Custom Quote'
    },
    {
      title: 'Advanced Fiber Laser Technology',
      subtitle: 'Unmatched precision for intricate designs and complex patterns',
      image: '/images/tFpIxx2XZpzn.jpg',
      cta: 'View Services'
    },
    {
      title: 'Custom Metal Art & Decor',
      subtitle: 'Transform your space with beautiful handcrafted metal artwork',
      image: '/images/PwyNTJmZdOgo.jpg',
      cta: 'Browse Products'
    }
  ];

  useEffect(() => {
    if (!isAutoPlay) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isAutoPlay, slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
    setIsAutoPlay(false);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
    setIsAutoPlay(false);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
    setIsAutoPlay(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-md">
        {/* Top Bar */}
        <div className="bg-secondary text-secondary-foreground py-2 px-4 md:px-8 text-sm flex flex-col md:flex-row justify-between items-center gap-2">
          <div className="flex gap-4 items-center">
            <a href="tel:+923154216083" className="hover:text-accent transition-colors flex items-center gap-1">
              <Phone size={16} /> +92 315 4216083
            </a>
            <a href="mailto:ironartofficial3@gmail.com" className="hover:text-accent transition-colors flex items-center gap-1">
              <Mail size={16} /> ironartofficial3@gmail.com
            </a>
          </div>
          <span className="text-xs md:text-sm font-medium">5+ Years of Excellence in Metal Fabrication</span>
        </div>

        {/* Navigation */}
        <nav className="flex items-center justify-between px-4 md:px-8 py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
              <span className="font-bold text-accent-foreground text-lg">IA</span>
            </div>
            <span className="font-bold text-foreground hidden sm:inline">Iron Art</span>
          </div>

          <ul className="hidden md:flex gap-8 items-center">
            {['Home', 'About', 'Services', 'Products', 'Contact', 'Query', 'Blog'].map((item) => (
              <li key={item}>
                <a href={`#${item.toLowerCase()}`} className="text-foreground hover:text-accent transition-colors font-medium">
                  {item}
                </a>
              </li>
            ))}
          </ul>

          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
            Get a Custom Quote
          </Button>
        </nav>
      </header>

      {/* Hero Slider */}
      <section className="relative h-96 md:h-screen overflow-hidden">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40" />
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center text-white px-4">
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 max-w-4xl">
                {slide.title}
              </h1>
              <p className="text-lg md:text-2xl mb-8 max-w-2xl text-gray-200">
                {slide.subtitle}
              </p>
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-6 text-lg">
                {slide.cta}
              </Button>
            </div>
          </div>
        ))}

        {/* Slider Controls */}
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-accent/80 hover:bg-accent text-accent-foreground p-3 rounded-lg transition-all"
          aria-label="Previous slide"
        >
          <ChevronLeft size={24} />
        </button>

        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-accent/80 hover:bg-accent text-accent-foreground p-3 rounded-lg transition-all"
          aria-label="Next slide"
        >
          <ChevronRight size={24} />
        </button>

        {/* Slide Indicators */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex gap-3">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-accent w-8' : 'bg-white/50 hover:bg-white/75'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 md:py-24 bg-background">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Our Services</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive metal fabrication solutions for industrial and commercial needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: 'CNC Plasma Cutting',
                desc: 'High-precision plasma cutting for thick metal sheets with exceptional speed and accuracy. Ideal for industrial applications requiring...',
                image: '/images/Wd3LH54Gc5BC.jpg'
              },
              {
                title: 'Fiber Laser Cutting',
                desc: 'State-of-the-art fiber laser technology delivering unmatched precision and intricate detail for complex designs and thin...',
                image: '/images/tFpIxx2XZpzn.jpg'
              },
              {
                title: 'Flame Cutting',
                desc: 'Traditional yet reliable flame cutting method perfect for heavy-duty applications and extremely thick metal plates where power...',
                image: '/images/v8zPkhoujRIW.jpg'
              },
              {
                title: 'CNC Bending',
                desc: 'Precision metal bending and forming services using advanced CNC press brake technology for accurate angles and...',
                image: '/images/5i9QO3bUcAOm.jpg'
              },
              {
                title: 'Engraving & Marking',
                desc: 'Professional laser engraving and marking services for permanent identification, branding, and decorative purposes on...',
                image: '/images/JRUDnjT1LzI9.webp'
              }
            ].map((service, idx) => (
              <div
                key={idx}
                className="group border-2 border-dashed border-accent/30 rounded-lg overflow-hidden hover:border-accent transition-all duration-300 hover:shadow-lg"
              >
                <div
                  className="h-48 bg-cover bg-center group-hover:scale-105 transition-transform duration-300"
                  style={{ backgroundImage: `url('${service.image}')` }}
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-3 text-foreground">{service.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{service.desc}</p>
                  <a href="#" className="text-accent font-semibold hover:text-accent/80 transition-colors inline-flex items-center gap-2">
                    Learn More →
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section id="products" className="py-16 md:py-24 bg-muted/50">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Featured Products</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explore our collection of custom metal art and decorative pieces
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {[
              {
                title: 'Geometric Wall Art',
                desc: 'Modern abstract geometric metal wall art piece with intricate cutout patterns. Perfect for contemporary home or office decor.',
                size: '24" x 24"',
                price: 'PKR 8,500',
                image: '/images/00OCrMTm7PLe.jpg'
              },
              {
                title: 'Islamic Calligraphy Art',
                desc: 'Elegant Arabic calligraphy metal wall decor featuring beautiful Islamic script. Premium quality craftsmanship for spiritual spaces.',
                size: '36" x 18"',
                price: 'PKR 12,000',
                image: '/images/PwyNTJmZdOgo.jpg'
              },
              {
                title: 'Abstract Metal Sculpture',
                desc: 'Contemporary abstract metal art piece with flowing geometric design. A statement piece for modern interiors.',
                size: '30" x 30"',
                price: 'PKR 15,500',
                image: '/images/2ViXhanNusjc.png'
              }
            ].map((product, idx) => {
              const whatsappMessage = encodeURIComponent(
                `Hi Iron Art! I'm interested in the ${product.title} (${product.size}) priced at ${product.price}. Can you provide more details and availability?`
              );
              const whatsappUrl = `https://wa.me/923154216083?text=${whatsappMessage}`;
              
              return (
              <div key={idx} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow">
                <div
                  className="h-64 bg-cover bg-center"
                  style={{ backgroundImage: `url('${product.image}')` }}
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{product.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{product.desc}</p>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-muted-foreground">Size: {product.size}</span>
                  </div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-lg font-bold text-accent">{product.price}</span>
                  </div>
                  <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                    <Button className="w-full bg-green-500 hover:bg-green-600 text-white">
                      Inquire via WhatsApp
                    </Button>
                  </a>
                </div>
              </div>
            );
            })}
          </div>

          <div className="text-center">
            <Button variant="outline" className="border-accent text-accent hover:bg-accent/10">
              View All Products
            </Button>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="about" className="py-16 md:py-24 bg-background">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Why Choose Iron Art</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Leading provider of industrial metal fabrication services and custom metal art solutions
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: '⏱️', title: '5+ Years Experience', desc: 'Proven track record in metal fabrication excellence' },
              { icon: '🎯', title: 'One-Stop Service', desc: 'Complete solutions from design to delivery' },
              { icon: '💰', title: 'Low-Cost Implementation', desc: 'Competitive pricing without compromising quality' },
              { icon: '📄', title: 'Multiple File Formats', desc: 'We accept: DXF, DWG, CDR, AI, PDF' }
            ].map((item, idx) => (
              <div key={idx} className="text-center p-6 rounded-lg border border-border hover:border-accent transition-colors">
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-16 md:py-24 bg-muted/50">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Trusted by businesses and individuals across Pakistan
            </p>
          </div>

          <div className="bg-white rounded-lg p-8 md:p-12 text-center shadow-md border border-border">
            <div className="flex justify-center gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <span key={i} className="text-2xl text-accent">⭐</span>
              ))}
            </div>
            <h3 className="text-2xl font-bold mb-2">Excellent Service</h3>
            <p className="text-muted-foreground mb-2">Rated 4.9/5 based on 100+ reviews</p>
            <p className="text-sm text-muted-foreground">Google Reviews Widget Integration Space</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary text-secondary-foreground py-12 md:py-16">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            {/* About */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                  <span className="font-bold text-accent-foreground text-sm">IA</span>
                </div>
                <span className="font-bold text-lg">Iron Art</span>
              </div>
              <p className="text-sm text-secondary-foreground/80">
                Leading provider of precision metal cutting and fabrication services with 5+ years of excellence.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-bold mb-4 text-accent">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                {['Home', 'About Us', 'Services', 'Products', 'Blog'].map((link) => (
                  <li key={link}>
                    <a href={`#${link.toLowerCase()}`} className="hover:text-accent transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Services */}
            <div>
              <h4 className="font-bold mb-4 text-accent">Our Services</h4>
              <ul className="space-y-2 text-sm">
                {['Plasma Cutting', 'Laser Cutting', 'Flame Cutting', 'CNC Bending', 'Engraving & Marking'].map((service) => (
                  <li key={service}>
                    <a href="#" className="hover:text-accent transition-colors">
                      {service}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-bold mb-4 text-accent">Contact Us</h4>
              <ul className="space-y-3 text-sm">
                <li className="flex items-center gap-2">
                  <Phone size={16} />
                  <a href="tel:+923154216083" className="hover:text-accent transition-colors">
                    +92 315 4216083
                  </a>
                </li>
                <li className="flex items-center gap-2">
                  <Mail size={16} />
                  <a href="mailto:ironartofficial3@gmail.com" className="hover:text-accent transition-colors">
                    ironartofficial3@gmail.com
                  </a>
                </li>
                <li className="flex items-center gap-2">
                  <MapPin size={16} />
                  <span>Industrial Area, Lahore, Pakistan</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Social Links */}
          <div className="border-t border-secondary-foreground/20 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-secondary-foreground/80 mb-4 md:mb-0">
              © 2025 Iron Art. All rights reserved.
            </p>
            <div className="flex gap-4">
              {[
                { icon: Facebook, label: 'Facebook' },
                { icon: Instagram, label: 'Instagram' },
                { icon: Twitter, label: 'Twitter' },
                { icon: Linkedin, label: 'LinkedIn' }
              ].map(({ icon: Icon, label }) => (
                <a
                  key={label}
                  href="#"
                  className="w-10 h-10 rounded-lg bg-accent/20 hover:bg-accent text-accent hover:text-accent-foreground transition-all flex items-center justify-center"
                  aria-label={label}
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/923154216083"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 w-14 h-14 bg-green-500 hover:bg-green-600 text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all z-40 animate-pulse hover:animate-none"
        aria-label="Chat on WhatsApp"
      >
        <svg className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.869 1.171c-1.519.761-2.783 1.844-3.702 3.112C2.505 10.9 2 12.469 2 14.077c0 1.321.292 2.592.843 3.777l-1.796 6.561 6.761-1.772c1.124.627 2.398.954 3.772.96h.004c5.517 0 10-4.486 10-10.003 0-2.651-1.028-5.145-2.897-7.01-1.87-1.865-4.36-2.89-7.016-2.89z" />
        </svg>
      </a>
    </div>
  );
}

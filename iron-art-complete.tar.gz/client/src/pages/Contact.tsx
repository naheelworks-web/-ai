import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Mail, Phone, MapPin } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const submitMutation = trpc.contact.submit.useMutation({
    onSuccess: () => {
      toast.success('Thank you! Your inquiry has been sent. We will contact you soon.');
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
    },
    onError: (error) => {
      toast.error('Failed to send inquiry. Please try again.');
      console.error(error);
    },
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-md">
        <div className="bg-secondary text-secondary-foreground py-2 px-4 md:px-8 text-sm flex flex-col md:flex-row justify-between items-center gap-2">
          <div className="flex gap-4 items-center">
            <a href="tel:+923154216083" className="hover:text-accent transition-colors flex items-center gap-1">
              <Phone size={16} /> +92 315 4216083
            </a>
            <a href="mailto:ironartofficial3@gmail.com" className="hover:text-accent transition-colors flex items-center gap-1">
              <Mail size={16} /> ironartofficial3@gmail.com
            </a>
          </div>
          <span className="text-xs md:text-sm font-medium">5+ Years of Excellence in Metal Fabrication</span>
        </div>

        <nav className="flex items-center justify-between px-4 md:px-8 py-4">
          <a href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
              <span className="font-bold text-accent-foreground text-lg">IA</span>
            </div>
            <span className="font-bold text-foreground hidden sm:inline">Iron Art</span>
          </a>

          <ul className="hidden md:flex gap-8 items-center">
            {['Home', 'About', 'Services', 'Products', 'Contact', 'Query', 'Blog'].map((item) => (
              <li key={item}>
                <a href={`/${item.toLowerCase()}`} className="text-foreground hover:text-accent transition-colors font-medium">
                  {item}
                </a>
              </li>
            ))}
          </ul>

          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
            Get a Custom Quote
          </Button>
        </nav>
      </header>

      {/* Contact Section */}
      <section className="py-16 md:py-24">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Get in Touch</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Have a project in mind? We'd love to hear from you. Send us your inquiry and we'll respond within 24 hours.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            {/* Contact Info */}
            <div className="lg:col-span-1">
              <div className="space-y-8">
                <div className="flex gap-4">
                  <Phone className="text-accent flex-shrink-0 mt-1" size={24} />
                  <div>
                    <h3 className="font-bold mb-2">Phone</h3>
                    <a href="tel:+923154216083" className="text-muted-foreground hover:text-accent transition-colors">
                      +92 315 4216083
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Mail className="text-accent flex-shrink-0 mt-1" size={24} />
                  <div>
                    <h3 className="font-bold mb-2">Email</h3>
                    <a href="mailto:ironartofficial3@gmail.com" className="text-muted-foreground hover:text-accent transition-colors">
                      ironartofficial3@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <MapPin className="text-accent flex-shrink-0 mt-1" size={24} />
                  <div>
                    <h3 className="font-bold mb-2">Location</h3>
                    <p className="text-muted-foreground">
                      Industrial Area<br />
                      Lahore, Pakistan
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <form onSubmit={handleSubmit} className="space-y-6 bg-card p-8 rounded-lg border border-border">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Name *</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                      placeholder="Your Name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email *</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                    placeholder="+92 300 1234567"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Subject *</label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                    placeholder="Project Inquiry"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Message *</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                    placeholder="Tell us about your project..."
                  />
                </div>

                <Button
                  type="submit"
                  disabled={submitMutation.isPending}
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground py-3"
                >
                  {submitMutation.isPending ? 'Sending...' : 'Send Inquiry'}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary text-secondary-foreground py-12 md:py-16">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center">
            <p className="text-sm text-secondary-foreground/80">
              © 2025 Iron Art. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

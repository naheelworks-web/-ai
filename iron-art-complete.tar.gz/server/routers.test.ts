import { describe, it, expect, vi, beforeEach } from 'vitest';
import { z } from 'zod';

// Mock the database functions
vi.mock('./db', () => ({
  createContactInquiry: vi.fn(async (inquiry) => {
    if (!inquiry.name || !inquiry.email || !inquiry.subject || !inquiry.message) {
      throw new Error('Missing required fields');
    }
    return { id: 1, ...inquiry, createdAt: new Date(), updatedAt: new Date() };
  }),
  getContactInquiries: vi.fn(async () => [
    {
      id: 1,
      name: 'Test User',
      email: 'test@example.com',
      phone: '+92 300 1234567',
      subject: 'Test Inquiry',
      message: 'Test message',
      productId: null,
      status: 'new',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]),
  getBlogPosts: vi.fn(async (published) => {
    if (published === true) {
      return [
        {
          id: 1,
          title: 'Getting Started with Metal Fabrication',
          slug: 'getting-started-metal-fabrication',
          excerpt: 'Learn the basics of metal fabrication',
          content: 'Full content here...',
          author: 'Iron Art',
          category: 'Guide',
          imageUrl: '/images/blog-1.jpg',
          published: 'published',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];
    }
    return [];
  }),
  getBlogPostBySlug: vi.fn(async (slug) => {
    if (slug === 'getting-started-metal-fabrication') {
      return {
        id: 1,
        title: 'Getting Started with Metal Fabrication',
        slug: 'getting-started-metal-fabrication',
        excerpt: 'Learn the basics of metal fabrication',
        content: 'Full content here...',
        author: 'Iron Art',
        category: 'Guide',
        imageUrl: '/images/blog-1.jpg',
        published: 'published',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    }
    return undefined;
  }),
}));

describe('Contact Inquiry Validation', () => {
  it('should validate contact inquiry input', () => {
    const schema = z.object({
      name: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      subject: z.string().min(1),
      message: z.string().min(1),
      productId: z.string().optional(),
    });

    const validInput = {
      name: 'John Doe',
      email: 'john@example.com',
      phone: '+92 300 1234567',
      subject: 'Plasma Cutting Inquiry',
      message: 'I need plasma cutting services for a project',
    };

    expect(() => schema.parse(validInput)).not.toThrow();
  });

  it('should reject invalid email', () => {
    const schema = z.object({
      name: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      subject: z.string().min(1),
      message: z.string().min(1),
      productId: z.string().optional(),
    });

    const invalidInput = {
      name: 'John Doe',
      email: 'invalid-email',
      subject: 'Inquiry',
      message: 'Message',
    };

    expect(() => schema.parse(invalidInput)).toThrow();
  });

  it('should reject empty required fields', () => {
    const schema = z.object({
      name: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      subject: z.string().min(1),
      message: z.string().min(1),
      productId: z.string().optional(),
    });

    const invalidInput = {
      name: '',
      email: 'test@example.com',
      subject: 'Inquiry',
      message: 'Message',
    };

    expect(() => schema.parse(invalidInput)).toThrow();
  });
});

describe('Blog Post Validation', () => {
  it('should validate blog post slug format', () => {
    const schema = z.object({ slug: z.string() });

    const validSlug = {
      slug: 'getting-started-metal-fabrication',
    };

    expect(() => schema.parse(validSlug)).not.toThrow();
  });

  it('should accept optional published filter', () => {
    const schema = z.object({
      published: z.boolean().optional(),
    });

    const input1 = { published: true };
    const input2 = { published: false };
    const input3 = {};

    expect(() => schema.parse(input1)).not.toThrow();
    expect(() => schema.parse(input2)).not.toThrow();
    expect(() => schema.parse(input3)).not.toThrow();
  });
});

describe('WhatsApp Message Generation', () => {
  it('should generate correct WhatsApp message for product', () => {
    const product = {
      title: 'Geometric Wall Art',
      size: '24" x 24"',
      price: 'PKR 8,500',
    };

    const message = `Hi Iron Art! I'm interested in the ${product.title} (${product.size}) priced at ${product.price}. Can you provide more details and availability?`;
    const encoded = encodeURIComponent(message);

    expect(encoded).toContain('Geometric%20Wall%20Art');
    expect(encoded).toContain('PKR%208%2C500');
  });

  it('should create valid WhatsApp URL', () => {
    const phoneNumber = '923154216083';
    const message = encodeURIComponent('Hi, I have an inquiry');
    const url = `https://wa.me/${phoneNumber}?text=${message}`;

    expect(url).toContain('wa.me');
    expect(url).toContain('text=');
    expect(url).toMatch(/^https:\/\/wa\.me\/\d+\?text=/);
  });
});
